package org.osce.wiredocs.event.file;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Timer;

import org.osce.wiredocs.control.WDResourceController;

/**
 * Handler for the file system watch service.
 * @author Gottfried Nindl
 * @version 1.0
 */
public class FileChangeObserver implements FileChangeListener {
	
	protected WDResourceController resource;	
	protected FileSystemWatchService watcher;		
	
	// Pause between file system event checks
	protected static final int WATCH_INTERVAL = 1000; 
	
	/**
	 * Initialise with the resource controller where actions
	 * might be delegated
	 * @param resource
	 *   Remote resource controller
	 */
	public FileChangeObserver(WDResourceController resource) {		
		this.resource = resource;	
	}
	
	/**
	 * Start the file watch service.
	 */
	public void watch(File file) {		
		watcher = new FileSystemWatchService(Paths.get(file.getAbsolutePath()), this);	
		// Run file watcher every second, don't run as a daemon as we don't want the app to terminate
	    new Timer(false).scheduleAtFixedRate(watcher, 0, WATCH_INTERVAL);
	}
	
	/**
	 * Terminate the file watch service
	 */
	public void unwatch() {
		watcher.cancel();
	}


	@Override
	public void fileCreated(Path path) {
		// do nothing
	}

	@Override
	public void fileModified(Path path) {
		resource.upload(path.toFile());
	}

	@Override
	public void fileDeleted(Path path) {
		// do nothing
	}
}
