package org.osce.wiredocs.ui;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.File;
import java.io.IOException;
import java.security.AccessController;
import java.security.PrivilegedAction;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

/**
 * UI layer containing all components, panels, dialogs etc.
 * @author Gottfried Nindl
 * @version 1.0
 */
public class FeedbackUIFrame extends JFrame implements FeedbackUI {
	
	private static final long serialVersionUID = 1L;
	
	protected ProgressPanel progress; // non blocking, updatable dialog

	/**
	 * Initialise an invisible GUI
	 */
	public FeedbackUIFrame() {
		super();
		
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			e.printStackTrace();
		}
		setVisible(false);
	}	
	
	@Override
	public void showMessage(String msg) {
		JOptionPane.showMessageDialog(this, msg);
	}
	
	@Override
	public void showError(String msg) {
		JOptionPane.showMessageDialog(this, msg, "An error occurred during processing", JOptionPane.ERROR_MESSAGE);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void openApp(final File file) {	    
	    AccessController.doPrivileged(new PrivilegedAction() {
	    	public Object run() {
	           	try {
	           		Desktop desktop = Desktop.getDesktop();
	           		desktop.open(file);
	           	}
	           	catch (IOException e) {
	           		if (progress == null) {
	           			showError("Opening file failed: " +e.getMessage());
	           		}
	           		else {
	           			progress.append("Opening file failed: " +e.getMessage());
	           		}
	        		e.printStackTrace();
	        	}
	           	return null;
	        }
	    });
	}
	
	@Override
	public void startProgress(String msg) {
		
		setPreferredSize(new Dimension(600, 250));
		
		progress = new ProgressPanel();
		progress.append(msg);
		progress.setVisible(true);
		progress.setProgressBarText("");
		
		Container contentPane = getContentPane();
		contentPane.add(progress, BorderLayout.CENTER);
		
		pack();
		center();
		setVisible(true);
		
	}
	
	@Override
	public void logProgress(String msg) {
		if (progress != null) {
			progress.append(msg); 
			progress.disableProgressbar();
		}
	}
	
	@Override
	public void endProgress() {		
		if (progress != null) progress.setVisible(false);
		setVisible(false);
	}
	
	/**
	 * Position this component in the middle of the screen.
	 */
	protected void center() {
		Toolkit toolkit =  Toolkit.getDefaultToolkit();
		Dimension dim = toolkit.getScreenSize();
		
		int x = (int)(dim.getWidth() - getWidth() - getInsets().left - getInsets().right) / 2;
		int y = (int)((dim.getHeight() - getHeight() - getInsets().top - getInsets().bottom) / 2);
		setLocation(x, y);
	}
	
}
