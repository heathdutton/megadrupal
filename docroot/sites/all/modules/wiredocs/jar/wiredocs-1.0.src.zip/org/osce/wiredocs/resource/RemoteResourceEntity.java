package org.osce.wiredocs.resource;

import java.util.Map;

/**
 * Virtual document object representing the remote entity.
 * @author Gottfried Nindl
 * @version 1.0
 */
public class RemoteResourceEntity implements RemoteResource {
	
	protected String downloadURL, uploadURL, fileName;	
	
	protected Map<String, String> params;
	
	@Override
	public String getDownloadURL() {
		return downloadURL;
	}

	@Override
	public void setDownloadURL(String downloadURL) {
		this.downloadURL = downloadURL;
	}

	@Override
	public String getUploadURL() {
		return uploadURL;
	}

	@Override
	public void setUploadURL(String uploadURL) {
		this.uploadURL = uploadURL;
	}
	
	@Override
	public String getFileName() {
		return fileName;
	}

	@Override
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	@Override
	public Map<String, String> getRequestProperties() {
		return params;
	}

	@Override
	public void setRequestProperties(Map<String, String> params) {
		this.params = params;
	}
	
}
