package org.osce.wiredocs.control;

import java.io.File;

import org.osce.wiredocs.event.resource.ResourceEventListener;

/**
 * Handles the business logic between local and remote system.
 * @author Gottfried Nindl
 * @version 1.0
 */
public interface WDResourceController {		
	
	/**
	 * Download a file from a remote repository.
	 * @return
	 *   local file
	 */
	public File download();
	
	/**
	 * Upload a file to a remote repository.
	 * @param file
	 *   local file
	 */
	public void upload(File file);
	
	/**
	 * Watch changes of a local file.
	 * @param file
	 *   local file
	 */
	public void observe(File file);		
	
	/**
	 * Get a listener firing on object events, e. g. when upload has started.
	 * @return
	 */
	public ResourceEventListener getListener();
	
	/**
	 * Provide a listener firing on object events, e. g. when download has finished.
	 * @param listener
	 */
	public void setListener(ResourceEventListener listener);

	
	
}
