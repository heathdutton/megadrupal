package org.osce.wiredocs.event.file;

import static java.nio.file.StandardWatchEventKinds.ENTRY_CREATE;
import static java.nio.file.StandardWatchEventKinds.ENTRY_DELETE;
import static java.nio.file.StandardWatchEventKinds.ENTRY_MODIFY;
import static java.nio.file.StandardWatchEventKinds.OVERFLOW;

import java.io.IOException;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.WatchEvent;
import java.nio.file.WatchEvent.Kind;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.TimerTask;

/**
 * We observe changes made to a specific file and delegate events to the provided listener.
 * Therefore we make use of the java.nio API introduced in version 1.7. As the watch service
 * can only listen to directories, we also encapsulate additional filtering logic here.
 * @author Gottfried Nindl
 * @version 1.0
 */
public class FileSystemWatchService extends TimerTask {
    
    private Path file;    
    private FileChangeListener listener;
    
    private WatchService watchService;  
    
    /**
     * Establish a file system interface and the watch service for the file.
     * @param pathname
     *   absolute path to the file
     * @throws IOException
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
	public FileSystemWatchService(final Path file, FileChangeListener listener) {
    	this.file = file;
    	this.listener = listener;
        
        try {
        	FileSystem fs = FileSystems.getDefault();
			watchService = fs.newWatchService();
	        // we can only listen to changes in directories, we match the file later
			 AccessController.doPrivileged(new PrivilegedAction() {
	            public Object run() {
	            	try {
	            		return file.getParent().register(watchService, ENTRY_CREATE, ENTRY_MODIFY, ENTRY_DELETE);
	            	} catch (IOException e) {
	        			e.printStackTrace();
	        		}
	            	return null;
	            }
			});
	        
		} catch (IOException e) {
			e.printStackTrace();
		}
    }    

    /**
     * Observe a specific file and return events to the listener (if initiated).
     * @throws IOException
     */
    public void run() {
    	WatchKey key;
        try { // iterate over watch keys
        	key = watchService.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
            return;
        }

        for (WatchEvent<?> e : key.pollEvents()) { // iterate over event queue
        	@SuppressWarnings("unchecked")
            WatchEvent<Path> event = (WatchEvent<Path>) e;                
            Kind<?> kind = event.kind(); // sort of event
			
    		if (kind == OVERFLOW) { // we don't support overflows
    		  continue;
    		}

            Path fileName = event.context(); // get file name
            Path child = file.getParent().resolve(fileName); // get absolute path of file
                
            // If file matches, trigger events.
            // OS tend to create additional temporary documents which we suppress here
            if (listener != null && child.equals(file)) { 
            	if (kind == ENTRY_CREATE) { 
                	listener.fileCreated(child);
                }
                if (kind == ENTRY_DELETE) {
                	listener.fileDeleted(child);
                }
                if (kind == ENTRY_MODIFY) {
                	listener.fileModified(child);
                }
            }
            
            boolean valid = key.reset();
            if (!valid) {
            	break;
            }
        }
    }       
    
    /**
     * Terminate watch service.
     * @throws IOException
     */
    public boolean cancel() {    	
    	try {
			watchService.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
    	return super.cancel();
	}
}