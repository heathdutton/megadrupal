package org.osce.wiredocs.event.file;

import java.io.File;
import java.nio.file.Path;

/**
 * Abstraction for file system events.
 * @author Gottfried Nindl
 * @version 1.0
 */
public interface FileChangeListener {	
	
	/**
	 * Starts the file watch service.
	 */
	public void watch(File file);
	
	/**
	 * Terminates the file watch service.
	 */
	public void unwatch();
	
	/**
	 * Event when file has been created.
	 * @param path
	 */
	public void fileCreated(Path path);
	
	/**
	 * Event when file has been modified.
	 * @param path
	 */
	public void fileModified(Path path);
	
	/**
	 * Event when file has been deleted.
	 * @param path
	 */
	public void fileDeleted(Path path);	
	
}
