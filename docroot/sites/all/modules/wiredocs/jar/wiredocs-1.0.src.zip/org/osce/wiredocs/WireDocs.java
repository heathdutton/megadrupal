package org.osce.wiredocs;


import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.osce.wiredocs.control.FileWDResourceHandler;
import org.osce.wiredocs.control.HTTPWDResourceHandler;
import org.osce.wiredocs.control.WDResourceController;
import org.osce.wiredocs.event.resource.ResourceEventListener;
import org.osce.wiredocs.event.resource.ResourceEventObserver;
import org.osce.wiredocs.resource.RemoteResource;
import org.osce.wiredocs.resource.RemoteResourceEntity;
import org.osce.wiredocs.ui.FeedbackUI;
import org.osce.wiredocs.ui.FeedbackUIFrame;

/**
 * The WireDocs library provides the possibility to edit a file online in the following way:
 * 
 * 1) Download the file
 * 2) Open appropriate local operating system editor
 * 3) Observe modifications of the local file
 * 4) If the file has been updated, upload it again
 * 
 * The library uses mainly observer and MVC design patterns. Bootstrapping and initial download
 * is done within this class. If the local file is modified an upload event is triggered. Further
 * the UI feedback is delegated to the event listeners.
 * 
 * - org.osce.wiredocs.control: Data handling, e. g. down- and upload
 * - org.osce.wiredocs.event: Events for file, down- and upload
 * - org.osce.wiredocs.resource: Virtual data object(s)
 * - org.osce.wiredocs.ui: User Interface, feedback layer
 * @author Gottfried Nindl
 * @version 1.0
 */
public class WireDocs {
	
	/**
	 * We create an initial invisible UI which is controlled by the
	 * resource event observer. The observer itself receives events
	 * triggered by the processing of the resource.
	 * @param resource
	 *   Virtual remote data object
	 * @throws Exception
	 */
	public WireDocs(RemoteResource resource) throws Exception {			
				
		// Determine the data handling, e. g. locally, via HTTP, FTP etc.
		WDResourceController handler = createHandler(resource);		
		
		if (handler != null) {
			// Graphical user interface for alerts, messages etc.
			FeedbackUI ui = new FeedbackUIFrame();
	
			// Global controller listening to resource handler events and capable of manipulating the UI
			// Subsequent program execution flow is continued in the listener methods
			// If you don't want a GUI, simply don't add this listener.
			ResourceEventListener listener = new ResourceEventObserver(ui);
			handler.setListener(listener);
			
			// download the document and trigger possible resource event listener events
			File file = handler.download();
			handler.observe(file);
		}
		else {
			throw new Exception("URI resource type " +resource.getDownloadURL() +" is not supported");
		}
	}
	
	/**
	 * Factory method for resource handling, e. g. locally, via HTTP, FTP etc.
	 * 
	 * @param resource
	 *   Virtual remote data object
	 * @return
	 *   WDResourceController data handler
	 */
	private WDResourceController createHandler(RemoteResource resource) {		
		
		try { // Determine where the resource resides, e. g. http, locally, ftp etc.
			URL url = new URL(resource.getDownloadURL());
			String protocol = url.getProtocol();
			switch (protocol) {
				case "http":
					return new HTTPWDResourceHandler(resource);
			}	
		} catch (MalformedURLException e) {
			File file = new File(resource.getDownloadURL());
			if (file.exists()) { // try a local file
				return new FileWDResourceHandler(resource);
			}
		}
		return null;
	}	
	
	// test method
	public static void main(String[] args) {
		// Initialise a virtual remote document object containing upload and download URLs
		if (args.length == 3) {
			RemoteResource resource = new RemoteResourceEntity();
				resource.setDownloadURL(args[0]);
				resource.setUploadURL(args[1]);
				resource.setFileName(args[2]);
				Map<String, String> params = new HashMap<String, String>();
					params.put("Cookie", args[3]);
				resource.setRequestProperties(params);
			try {
				new WireDocs(resource);
			} catch (Exception e) {
				e.printStackTrace();
			}	
		}			  
	}
}
