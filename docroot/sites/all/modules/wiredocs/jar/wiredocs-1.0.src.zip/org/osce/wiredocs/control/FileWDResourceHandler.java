package org.osce.wiredocs.control;

import java.io.File;
import java.io.IOException;

import org.osce.wiredocs.resource.RemoteResource;
import org.osce.wiredocs.util.FileUtils;

/**
 * Handles local repositories, mainly for testing purposes
 * @author Gottfried Nindl
 * @version 1.0
 */
public class FileWDResourceHandler extends WDResourceHandler {

	public FileWDResourceHandler(RemoteResource resource) {
		super(resource);		
	}
	
	@Override
	public File download() {		
		try {
			File sourceFile = new File(resource.getDownloadURL());
			File file = FileUtils.createTempFile(TMP_FILE_PREFIX, ""); // create temporary storage
			// inform observers that the download has begun
			if (listener != null) listener.downloadHasStarted(resource.getDownloadURL(), file);
			file = FileUtils.copyFile(sourceFile, file);
			// inform observers that the download has finished
			if (listener != null) listener.downloadHasFinished(resource.getDownloadURL(), file);
			return file;
			
		} catch (IOException e) {
			// inform observers that the download has failed
			if (listener != null) listener.downloadHasFailed(resource.getDownloadURL(), e);
			e.printStackTrace();
		}
		return null;
	}
	

	@Override
	public void upload(File file) {		
		try {
			File targetFile = new File(resource.getUploadURL());
			// inform observers that the upload has begun
			if (listener != null) listener.uploadHasStarted(file, resource.getUploadURL());
			FileUtils.copyFile(file, targetFile);
			// inform observers that the download has finished
			if (listener != null) listener.uploadHasFinished(file, resource.getUploadURL());
			
		} catch (IOException e) {
			// inform observers that the upload has failed
			if (listener != null) listener.uploadHasFailed(file, e);
			e.printStackTrace();
		}
	}
}
