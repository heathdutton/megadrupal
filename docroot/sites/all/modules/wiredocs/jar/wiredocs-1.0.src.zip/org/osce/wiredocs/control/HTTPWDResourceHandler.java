package org.osce.wiredocs.control;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;

import org.osce.wiredocs.resource.RemoteResource;
import org.osce.wiredocs.util.FileUtils;
import org.osce.wiredocs.util.HTTPUtils;

/**
 * Handles remote resources via the HTTP protocol.
 * @author Gottfried Nindl
 * @version 1.0
 */
public class HTTPWDResourceHandler extends WDResourceHandler {	

	public HTTPWDResourceHandler(RemoteResource resource) {
		super(resource);
	}
	
	@Override
	public File download() {		
		try {
			File file = allocateTempFile(); // create temporary storage			
			URL download = new URL(resource.getDownloadURL()); // get download URL
			// inform observers that the download has begun
			if (listener != null) listener.downloadHasStarted(resource.getDownloadURL(), file);	
			file = HTTPUtils.downloadFile(download, resource.getRequestProperties(), file); // download to file from remote location
			// inform observers that the download has finished
			if (listener != null) listener.downloadHasFinished(resource.getDownloadURL(), file);
			return file;
			
		} catch (IOException e) {
			// inform observers that the download has failed
			if (listener != null) listener.downloadHasFailed(resource.getDownloadURL(), e);
			e.printStackTrace();
		}
		return null;
	}	
	
	@Override
	public void upload(File file) {		
		try {
			URL upload = new URL(resource.getUploadURL()); // get upload URL
			
			// inform observers that the upload has begun
			if (listener != null) listener.uploadHasStarted(file, resource.getUploadURL());
			String response = HTTPUtils.uploadFile(file, resource.getRequestProperties(), upload); // download file to remote location
			// inform observers that the download has finished
			// TODO: check HTTP status code of response
			if (listener != null && response != null) {
				listener.uploadHasFinished(file, resource.getUploadURL());
			}			
		} catch (Exception e) {
			// inform observers that the upload has failed
			if (listener != null) listener.uploadHasFailed(file, e);
			e.printStackTrace();
		}
	}
	
	/**
	 * Create a temporary storage file.
	 * @return
	 *   temporary file
	 * @throws IOException
	 */
	protected File allocateTempFile() throws IOException {		
		String prefix = TMP_FILE_PREFIX; // standard prefix		
		try { // add host name
			prefix += "-" + URLEncoder.encode(new URL(resource.getDownloadURL()).getHost(), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		// add file name containing file type extension making 
		// it easier for the OS to detect the file associations
		String suffix = resource.getFileName();
		
		return FileUtils.createTempFile(prefix, suffix); // create temporary file
	}
}