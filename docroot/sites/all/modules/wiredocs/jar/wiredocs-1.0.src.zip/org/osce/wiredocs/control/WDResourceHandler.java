package org.osce.wiredocs.control;

import java.io.File;

import org.osce.wiredocs.event.file.FileChangeListener;
import org.osce.wiredocs.event.file.FileChangeObserver;
import org.osce.wiredocs.event.resource.ResourceEventListener;
import org.osce.wiredocs.resource.RemoteResource;

/**
 * This is the super class for all handlers (controllers) of a remote resource.
 * @author Gottfried Nindl
 * @version 1.0
 */
public abstract class WDResourceHandler implements WDResourceController {
	
	protected RemoteResource resource;
	protected ResourceEventListener listener;
	
	protected static final String TMP_FILE_PREFIX = "WIREDOCS";
	
	/**
	 * Initialise a remote resource.
	 * @param resource
	 */
	public WDResourceHandler(RemoteResource resource) {
		this.resource = resource;
	}
	
	@Override
	public abstract File download();

	@Override
	public abstract void upload(File file);
	
	@Override
	public void observe(File file) {
		FileChangeListener fileObserver = new FileChangeObserver(this);
		fileObserver.watch(file);
	}
	
	@Override
	public ResourceEventListener getListener() {
		return listener;
	}

	@Override
	public void setListener(ResourceEventListener listener) {
		this.listener = listener;
	}		
	
}
