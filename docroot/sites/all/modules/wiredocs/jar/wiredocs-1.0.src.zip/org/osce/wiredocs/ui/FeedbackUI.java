package org.osce.wiredocs.ui;

import java.io.File;

/**
 * Provides access to the UI layer.
 * @author Gottfried Nindl
 * @version 1.0
 */
public interface FeedbackUI {

	/**
	 * Show a simple information message box.
	 * @param msg
	 *   String message
	 */
	public void showMessage(String msg);
	
	/**
	 * Show an error message
	 * @param msg
	 *   String message
	 */
	public void showError(String msg);
	
	/**
	 * Open a file with the (operating system's) 
	 * associated application.
	 * @param file
	 *   Local file object
	 */
	public void openApp(File file);
	
	/**
	 * Start a progress dialog (non blocking).
	 * @param msg
	 *   String message
	 */
	public void startProgress(String msg);
	
	/**
	 * Append a new message to the progress dialog.
	 * @param msg
	 *   String message
	 */
	public void logProgress(String msg);
	
	/**
	 * Terminate a progress dialog.
	 */
	public void endProgress();
	
}
