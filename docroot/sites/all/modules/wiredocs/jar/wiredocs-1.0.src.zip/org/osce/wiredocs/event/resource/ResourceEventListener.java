package org.osce.wiredocs.event.resource;

import java.io.File;

/**
 * Listen to events during the processing of a remote resource.
 * @author Gottfried Nindl
 * @version 1.0
 */
public interface ResourceEventListener {
	
	/**
	 * Download of the file has been initialised.
	 * @param url
	 *   Download URL
	 * @param file
	 *   Destination download file location
	 */
	public void downloadHasStarted(String url, File file);
	
	/**
	 * Download of the file has been completed.
	 * @param url
	 *   Download URL
	 * @param file
	 *   Destination download file location
	 */
	public void downloadHasFinished(String url, File file);
	
	/**
	 * An error occurred while downloading the file.
	 * @param url
	 *   Download URL
	 * @param e
	 *   Java Exception
	 */
	public void downloadHasFailed(String url, Exception e);
	
	/**
	 * Upload of the local file has been initialised.
	 * @param file
	 *   Destination download file location
	 * @param url
	 *   Upload URL
	 */
	public void uploadHasStarted(File file, String url);
	
	/**
	 * Upload of the file has been completed.
	 * @param file
	 *   Destination download file location
	 * @param url
	 *   Upload URL
	 */
	public void uploadHasFinished(File file, String url);
	
	/**
	 * An error occurred while uploading the file
	 * @param file.
	 *   Destination download file location
	 * @param e
	 *   Java Exception
	 */
	public void uploadHasFailed(File file, Exception e);

}