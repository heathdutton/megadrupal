package org.osce.wiredocs.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Common HTTP manipulations.
 * @author Gottfried Nindl
 * @version 1.0
 */
public class HTTPUtils {	
	
	/**
	 * Download a file from a URL.
	 * @param url
	 *   HTTP URL where file is provided
	 * @param destination
	 *   Local file for storage
	 * @return
	 *   Destination file
	 * @throws IOException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static File downloadFile(final URL url, final Map<String, String> params, final File destination) throws IOException {		
		Object result = AccessController.doPrivileged(new PrivilegedAction() {
            public Object run() {
				try { // Download the file with java.nio channels
					URLConnection urlConn = url.openConnection();
					for (Map.Entry<String, String> entry: params.entrySet()) {
						urlConn.setRequestProperty(entry.getKey(), entry.getValue());
					}
					
					//String myCookie = "SESSe753ee0069eb3285ef6106cd350ee2b5=R5XpH0tQkUxpjDy5L4YTUZwXCuKBHmsrJghk9XcQYew";
					//urlConn.setRequestProperty("Cookie", myCookie);
					urlConn.connect();
					
					 ReadableByteChannel rbc = Channels.newChannel(urlConn.getInputStream());
					 FileOutputStream fos = new FileOutputStream(destination);
		             fos.getChannel().transferFrom(rbc, 0, 1 << 24);
		             fos.close();
				} catch (MalformedURLException e) {
					e.printStackTrace();
					return e;
				} catch (IOException e) {
					e.printStackTrace();
					return e;
				}
            	return destination;
            }
		});
		if (result instanceof IOException) {
			throw (IOException)result;
		}
		else {
			return (File)result;
		}
	}
	
	/**
	 * Upload a file to a URL.
	 * Various options have been investigated for uploading a file, including the Apache Commons library.
	 * We want to the app to stay simple and fast, i. e. limit the number and download of third party jars.
	 * The implementation of ClientHttpRequest provided on http://www.devx.com/Java/Article/17679/1954 
	 * beats them all.
	 * @param source
	 *   local file
	 * @param url
	 *   destination URL.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static String uploadFile(final File source, final Map<String, String> params, final URL url) throws IOException {
		Object response = AccessController.doPrivileged(new PrivilegedAction() {
			public Object run() {
				try {
					// We can add the file as a "userfile" parameter..
					Map<String, Object> parameters = new HashMap<String, Object>();
					parameters.put("userfile", source);
					// .. and simply post it via the ClientHttpRequest class!
					InputStream serverInput = ClientHttpRequest.post(url, params, parameters);
					
					// Read the server response
					BufferedReader reader = null;
					StringBuffer response = new StringBuffer();
					try {
						reader = new BufferedReader(new InputStreamReader(serverInput, "UTF-8"));
						for (String line; (line = reader.readLine()) != null;) {
							response.append(line + "\r\n");
						}
					} finally {
						if (reader != null) try { reader.close(); } catch (IOException logOrIgnore) {}
					}
					return response.toString();
				} catch (MalformedURLException e) {
					e.printStackTrace();
					return e;
				} catch (IOException e) {
					e.printStackTrace();
					return e;
				}
			}
		});
		if (response instanceof IOException) {
			throw (IOException)response;
		}
		else {
			return (String)response;
		}
	}
	
	public static void main(String[] args) {
		try { // Download the file with java.nio channels
			File destination = new File("D:\\test.html");
			URL url = new URL("http://drupal-7-dev.go.org/?q=node/2/edit");
			URLConnection urlConn = url.openConnection();
			String myCookie = "SESSe753ee0069eb3285ef6106cd350ee2b5=R5XpH0tQkUxpjDy5L4YTUZwXCuKBHmsrJghk9XcQYew";
			urlConn.setRequestProperty("Cookie", myCookie);
			urlConn.connect();
			
			 ReadableByteChannel rbc = Channels.newChannel(urlConn.getInputStream());
			 
			 FileOutputStream fos = new FileOutputStream(destination);
            fos.getChannel().transferFrom(rbc, 0, 1 << 24);
            fos.close();
		} catch (MalformedURLException e) {
			e.printStackTrace();
			//return e;
		} catch (IOException e) {
			e.printStackTrace();
			//return e;
		}
	}
}
