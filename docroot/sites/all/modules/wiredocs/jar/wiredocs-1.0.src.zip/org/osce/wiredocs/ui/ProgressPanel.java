package org.osce.wiredocs.ui;

import java.awt.BorderLayout;

import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 * A non blocking dialog where event information may be logged.
 * @author Gottfried Nindl
 * @version 1.0
 */
public class ProgressPanel extends JPanel {

	private static final long serialVersionUID = 1L;

	private JTextArea textArea = new JTextArea();
	private JProgressBar progressBar = new JProgressBar();

	public ProgressPanel() {
		setLayout(new BorderLayout());
		textArea.setEditable(false);		
		JScrollPane textAreaScrollPane = new JScrollPane(textArea);
		add(textAreaScrollPane, BorderLayout.CENTER);
		progressBar.setIndeterminate(true);
		progressBar.setStringPainted(true);
		add(progressBar, BorderLayout.SOUTH);
	}

	/**
	 * Append a line to the panel.
	 * @param text
	 */
	public void append(String text) {
		if (text != null) {
			textArea.append(text + "\n");
			textArea.setCaretPosition(textArea.getText().length());
		}
	}

	/**
	 * Set the text of the progress bar.
	 * @param text
	 */
	public void setProgressBarText(String text) {
		progressBar.setStringPainted(true);
		progressBar.setString(text);
	}

	/**
	 * Disable the progress bar.
	 */
	public void disableProgressbar() {
		progressBar.setStringPainted(false);
		progressBar.setIndeterminate(false);
	}

	/**
	 * Enable the progress bar.
	 */
	public void enableProgressbar() {
		progressBar.setStringPainted(true);
		progressBar.setIndeterminate(true);
	}
}
