package org.osce.wiredocs.event.resource;

import java.io.File;

import org.osce.wiredocs.ui.FeedbackUI;

/**
 * This handler receives remote resource events 
 * and notifies the UI about the results.
 * @author Gottfried Nindl
 * @version 1.0
 */
public class ResourceEventObserver implements ResourceEventListener {
	
	protected FeedbackUI ui;	
	
	/**
	 * Assign UI layer notifying about resource processing events.
	 * @param ui
	 *   GUI layer
	 */
	public ResourceEventObserver(FeedbackUI ui) {
		this.ui = ui;
	}

	@Override
	public void downloadHasStarted(String url, File file) {
		ui.startProgress("Starting download from " +url +" to " +file.getAbsolutePath());
	}

	@Override
	public void downloadHasFinished(String url, File file) {
		ui.openApp(file); // opens the resource (file) locally
		ui.endProgress(); // end intermediate progress dialog
	}

	@Override
	public void downloadHasFailed(String url, Exception e) {
		ui.logProgress("Download from " +url +" has failed: " +e.getMessage());
	}

	@Override
	public void uploadHasStarted(File file, String url) {
		ui.startProgress("Starting upload from "  +file.getAbsolutePath() +" to "  +url);
	}

	@Override
	public void uploadHasFinished(File file, String url) {
		ui.endProgress();
	}

	@Override
	public void uploadHasFailed(File file, Exception e) {
		ui.logProgress("Upload to " +file.getAbsolutePath() +" has failed: " +e.getMessage());
	}

}
