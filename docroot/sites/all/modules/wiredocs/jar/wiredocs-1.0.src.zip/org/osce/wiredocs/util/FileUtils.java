package org.osce.wiredocs.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.security.AccessController;
import java.security.PrivilegedAction;

/**
 * Common file manipulations.
 * @author Gottfried Nindl
 * @version 1.0
 */
public class FileUtils {
	
	/**
	 * Copies the contents of a file from a source to a destination.
	 * @param source
	 *   original file
	 * @param destination
	 *   target file
	 * @return
	 *  target file
	 * @throws IOException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static File copyFile(final File source, final File destination) throws IOException {	
		Object result = AccessController.doPrivileged(new PrivilegedAction() {
            public Object run() {
            	// Copy the file with java.nio with buffers, supposed to be faster.
            	try {
            		// source input stream
            		@SuppressWarnings("resource")
            		FileChannel inChannel = new FileInputStream(source).getChannel();
            		// destination output stream
            		@SuppressWarnings("resource")
            		FileChannel outChannel = new FileOutputStream(destination).getChannel();
            		try { // transfers bytes
            			inChannel.transferTo(0, inChannel.size(), outChannel);
            		}
            		catch (IOException e) {
            			e.printStackTrace();
            			return e;
            		}
            		finally {
            			if (inChannel != null) inChannel.close();
            			if (outChannel != null) outChannel.close();
            		}
            	} catch (IOException e) {
        			e.printStackTrace();
        			return e;
        		}
            	return destination;
            }
		});
		if (result instanceof IOException) {
			throw (IOException)result;
		}
		else {
			return (File)result;
		}	    
	}	
	
	/**
	 * Creates a temporary file.
	 * @param prefix
	 *   Prepended part of the file name
	 * @param suffix
	 *   Appended part of the file name
	 * @return
	 *   created temporary file
	 * @throws IOException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static File createTempFile(final String prefix, final String suffix) throws IOException {		
		Object result = AccessController.doPrivileged(new PrivilegedAction() {
            public Object run() {
            	try { // limit prefix to hundred characters
            		StringBuffer buffer = new StringBuffer(100);
            		buffer.append(prefix);
            		buffer.append("-");		
            		if (buffer.length() > 100) {
            			buffer.delete(101, buffer.length());
            		}
            		// return temporary file
					return File.createTempFile(buffer.toString(), suffix); 
				} catch (IOException e) {
					e.printStackTrace();
					return e;
				}
            }
        });
		if (result instanceof IOException) {
			throw (IOException)result;
		}
		else {
			return (File)result;
		}		
	}
}
