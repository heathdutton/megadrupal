package org.osce.wiredocs;

import java.applet.Applet;
import java.util.HashMap;
import java.util.Map;

import org.osce.wiredocs.resource.RemoteResource;
import org.osce.wiredocs.resource.RemoteResourceEntity;

/**
 * This Java applet provides a more or less invisible interface between the web page
 * and the app's file handling. It has to access the file system which is forbidden
 * by the default. There are two ways to address this problem: either a local 
 * security policy is set up granting enhanced permissions or the applet is signed.
 * The latter is recommended as users might not be able to edit JRE runtime settings.
 * The first option is feasible if we deploy the applet in an IT controlled environment
 * where we can set the security policy of each workstation.
 * @author Gottfried Nindl
 * @version 1.0
 */
public class WireDocsApplet extends Applet {	
	
	private static final long serialVersionUID = 1L;
	
	/**
	 * Stars the editing process. This function can be accessed by JavaSciprt like
	 * "document.APPLETNAME.edit()". 
	 * 
	 * @param download
	 *   URL for downloading a document
	 * @param upload
	 *   URL for uploading a document
	 */
	public void edit(){
	  try {
		// Initialise a virtual remote document object containing upload and download URLs
		RemoteResource resource = new RemoteResourceEntity();
			resource.setDownloadURL(this.getParameter("downloadURL"));
			resource.setUploadURL(this.getParameter("uploadURL"));
			resource.setFileName(this.getParameter("filename"));
			Map<String, String> params = new HashMap<String, String>();
				params.put("cookie", this.getParameter("Cookie"));
			resource.setRequestProperties(params);			
		new WireDocs(resource);
	  } catch (Exception e) {
		e.printStackTrace();
	  }
	}
}
