package org.osce.wiredocs.resource;

import java.util.Map;

/**
 * Virtual document representing the remote resource.
 * @author Gottfried Nindl
 * @version 1.0
 */
public interface RemoteResource {

	public String getDownloadURL();

	public void setDownloadURL(String downloadURL);

	public String getUploadURL();

	public void setUploadURL(String uploadURL);

	public String getFileName();

	public void setFileName(String fileName);
	
	public Map<String, String> getRequestProperties();
	
	public void setRequestProperties(Map<String, String> params);

}